

<?php $__env->startSection('container'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH V:\Laravel\vendinq\resources\views/profile.blade.php ENDPATH**/ ?>